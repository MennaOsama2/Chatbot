<?php
session_start();
// connecting to database
$conn = mysqli_connect("localhost", "root", "", "botaou_db") or die("Database Error");

// getting user message through ajax
//$getMesg = mysqli_real_escape_string($conn, $_POST['text']);

$getMesg = $_POST['text'];
if (!isset($_SESSION['welcomeMsg'])) {
    if (preg_match("/subject/i", $getMesg) || preg_match("/advising/i", $getMesg)) {
        
        
        $_SESSION['welcomeMsg'] = $getMesg;
        sleep(3);
        echo ("What is your faculty?");
    } else {
        sleep(3);
        echo "Sorry i couldn't understand you, would you re-enter your answer?";
    }
} else if (!isset($_SESSION['faculty'])) {
    if (strlen($getMesg) > 1) {
        $data = strtolower($getMesg);
        $check_data = "SELECT id FROM faculties WHERE  name LIKE '%$data%'";
        $run_query = mysqli_query($conn, $check_data) or die("Error");
        if (mysqli_num_rows($run_query) > 0) {
            $fetch_data = mysqli_fetch_assoc($run_query);
            $_SESSION['faculty'] = $fetch_data['id']; 
            sleep(3);
            echo ("what is your major?");
        }else{
            sleep(3);
            echo "Sorry i couldn't understand you, would you re-enter your faculty ?"; 
        }
    } else {
        sleep(3);
        echo "Sorry i couldn't understand you, would you re-enter your faculty ?";
    }
} else if (!isset($_SESSION['major'])) {
    if (strlen($getMesg) > 1) {
        $data = strtolower($getMesg);
        $check_data = "SELECT id FROM majors WHERE  name LIKE '%$data%'";
        $run_query = mysqli_query($conn, $check_data) or die("Error");
        if (mysqli_num_rows($run_query) > 0) {
            $fetch_data = mysqli_fetch_assoc($run_query);
            $_SESSION['major'] = $fetch_data['id']; 
            sleep(3);
            echo ("what is your year?");
        }else{
            sleep(3);
            echo "Sorry i couldn't understand you, would you re-enter your major ?"; 
        }
    } else {
        sleep(3);
        echo "Sorry i couldn't understand you, would you re-enter your major ?";
    } 
} else if (!isset($_SESSION['year'])) {
    if (strlen($getMesg) >= 0) {
        $data = strtolower($getMesg);
        $check_data = "SELECT id FROM years WHERE  name LIKE '%$data%'";
        $run_query = mysqli_query($conn, $check_data) or die("Error");
        if (mysqli_num_rows($run_query) > 0) {
            $fetch_data = mysqli_fetch_assoc($run_query);
            $_SESSION['year'] = $fetch_data['id']; 
            sleep(3);
            echo ("what is your semester?");
        }else{
            sleep(3);
            echo "Sorry i couldn't understand you, would you re-enter your year ?"; 
        }
    } else {
        sleep(3);
        echo "Sorry i couldn't understand you, would you re-enter year ?";
    }
} else if (!isset($_SESSION['semester'])) {
    if (strlen($getMesg) >= 0) {
        $data = strtolower($getMesg);
        $check_data = "SELECT id FROM semesters WHERE  name LIKE '%$data%'";
        $run_query = mysqli_query($conn, $check_data) or die("Error");
        if (mysqli_num_rows($run_query) > 0) {
            $fetch_data = mysqli_fetch_assoc($run_query);
            $_SESSION['semester'] = $fetch_data['id']; 
        }else{
            sleep(3);
            echo "Sorry i couldn't understand you, would you re-enter your semester ?"; 
        }
        $faculty_id= $_SESSION['faculty'];
        $year_id= $_SESSION['year'];
        $semester_id= $_SESSION['semester'];
        $major_id= $_SESSION['major'];
        

        $final_data = "SELECT name, hours FROM `subjects` WHERE faculty_id = $faculty_id AND semester_id = $semester_id AND major_id = $major_id AND year_id = $year_id";
        $final_query = mysqli_query($conn, $final_data) or die("Error");
        $total=0;
        sleep(3);
        if (mysqli_num_rows($final_query) > 0) {
            echo("The courses are: ");
           while($final_result = mysqli_fetch_assoc($final_query)) {
            $total+= $final_result['hours'];
            echo ($final_result['name']." ---- ");
           }
           echo('Total credit hours are =' .$total.' hours');
        }
            session_unset();
    } else {
        sleep(3);
        echo "Sorry i couldn't understand you, would you re-enter semster ?";
    }
} else {
    sleep(3);
    echo "Sorry i couldn't understand you, would you re-enter your answer out?";
}
