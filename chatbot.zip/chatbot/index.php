<!DOCTYPE html>
<html>
<head>
    <title>Login/ AOU Student Advising ChatBot</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">


    <link rel="shourtcut icon" href="kisspng-chatbot-artificial-intelligence-internet-bot-smile-bobchats-facebook-chatbot-developer-5b7cd61a838ac4.2804704615349079305388.png">
    <link rel="stylesheet" href="s.css">


</head> 
<body calss='all_1'>
    <form action ="login.php" method="post">
    <?php
      if (!empty($_GET["error"])) {
        header("Refresh:3;url=index.php");
      ?>
      <div class="alert alert-danger" role="alert">
          <strong>
            <?php
            switch ($_GET["error"]) {
              case "invalid_login":
                echo "Invalid ID or Password";
                break;
              case "empty":
                echo "ID and Password are required";
                break;
              case "secure_page":
                echo "Please Login First";
                break;
            }
            ?>
          </strong>
        </div>
        <?php
      }
      ?>

        <div class="all">
            <DIV class="img"> 
            <img class="im" src="kisspng-chatbot-artificial-intelligence-internet-bot-smile-bobchats-facebook-chatbot-developer-5b7cd61a838ac4.2804704615349079305388.png" alt="avatar">
            </DIV>
            <br><br>
            <input class="textbox" type="text" placeholder="Enter Your UNI ID" name="uniid">
            <br><br>
            <input class="textbox" type="password" placeholder="Enter Your password" name="pw">
            <br><br>
            <div class="B">
            <button class="loginbt"  style="width: 50%;" type="submit">Login</button>
             </div>

            <br>
            <label>
                <input style="width: auto;" type="checkbox">Remember me
            </label>
            <br>
        </div>
        </form>

</body>
</html>