<?php
session_start();

//connection to data base
$conn = mysqli_connect("localhost", "root", "", "botaou_db") or die("Database Error");

//validate inputes
if (!empty($_POST["uniid"]) && !empty($_POST["pw"])) {
    $uniid=$_POST["uniid"];
        $pw = $_POST["pw"];
        $rslt = mysqli_query($conn, " SELECT * FROM users WHERE uniid= '$uniid' AND password= '$pw' ");
        if ($user_data = mysqli_fetch_assoc($rslt)) {
            $_SESSION["user_id"] = $user_data["id"];
            header("location:bot.php");
        } else {
            header("location:index.php?error=invalid_login");
        }
} else {
    header("location:index.php?error=empty");
}
