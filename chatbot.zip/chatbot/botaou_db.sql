-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2021 at 08:59 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `botaou_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `id` int(15) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`id`, `name`) VALUES
(1, 'computer science      cs'),
(2, 'business administration         bus'),
(3, 'media and mass comm'),
(4, 'graphic and multimedia design and technology'),
(5, 'language studies ');

-- --------------------------------------------------------

--
-- Table structure for table `majors`
--

CREATE TABLE `majors` (
  `id` int(15) NOT NULL,
  `name` varchar(40) NOT NULL,
  `faculty_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `majors`
--

INSERT INTO `majors` (`id`, `name`, `faculty_id`) VALUES
(1, 'computer science     general    cs', 1),
(2, 'information technology    it', 1),
(3, 'computing with business ', 1),
(4, 'network and security', 1),
(5, 'web development ', 1),
(6, 'accounting ', 2),
(7, 'finance ', 2),
(8, 'marketing ', 2),
(9, 'management ', 2),
(10, 'human resource management   hr', 2),
(11, 'literature', 5),
(12, 'literature and translation', 5),
(13, 'media and journalism / public relations ', 3),
(14, ' media- electronic media program', 3),
(15, ' media- radio and television program', 3),
(16, 'graphic and multimedia design technology', 4);

-- --------------------------------------------------------

--
-- Table structure for table `semesters`
--

CREATE TABLE `semesters` (
  `id` int(15) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semesters`
--

INSERT INTO `semesters` (`id`, `name`) VALUES
(1, 'first 1 one'),
(2, 'second 2 two');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `hours` varchar(10) NOT NULL,
  `year_id` int(11) NOT NULL,
  `faculty_id` int(15) NOT NULL,
  `semester_id` int(15) NOT NULL,
  `major_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `hours`, `year_id`, `faculty_id`, `semester_id`, `major_id`) VALUES
(1, 'GR101 3 Self-Learning Skills \r\n', '3', 1, 1, 1, 1),
(2, 'AR111 3 Arabic Communication Skills ', '3', 1, 1, 1, 1),
(3, 'EL111 3 English Communication Skills ', '3', 1, 1, 1, 1),
(4, 'TU170 3 Computing Essentials', '3', 1, 1, 1, 1),
(5, 'MT131 4 Discrete Mathematics', '4', 1, 1, 1, 1),
(6, 'AR112 3 Arabic Communication Skills ', '3', 1, 1, 2, 1),
(7, 'EL112 3 English Communication Skills ', '3', 1, 1, 2, 1),
(8, 'TM103 4 Computer Organization and\r\nArchitecture', '4', 1, 1, 2, 1),
(9, 'MT129 4 Calculus and Probability', '4', 1, 1, 2, 1),
(10, 'GR111  3 Arabic Islamic Civilization', '3', 1, 1, 2, 1),
(11, 'TM105 4 Introduction to Programming', '4', 2, 1, 1, 1),
(12, 'MT132 4 Linear Algebra', '4', 2, 1, 1, 1),
(13, 'TM111 8 Introduction to Computing and Information Technology I ', '8', 2, 1, 1, 1),
(14, 'TM112 8 Introduction to Computing and Information Technology II', '8', 2, 1, 2, 1),
(15, 'M251 8 Object-Oriented Programming using Java', '8', 2, 1, 2, 1),
(16, 'MS102 3 Physics', '3', 2, 1, 2, 1),
(17, 'TM260 4 Security, Ethics and Privacy in IT and Computing', '4', 3, 1, 1, 1),
(18, 'T227 8 Change, Strategy and Project\r\nat Work', '8', 3, 1, 1, 1),
(19, 'M269 8 Algorithms, Data Structures and Computability', '8', 3, 1, 2, 1),
(20, 'TM298 4 Operating Systems', '4', 3, 1, 2, 1),
(21, 'TM240 4 Computer Graphics and\r\nMultimedia', '4', 3, 1, 2, 1),
(22, 'TM351 8 Data Management and\r\nAnalysis', '8', 4, 1, 1, 1),
(23, 'TM354 8 Software Engineering \r\n', '8', 4, 1, 1, 1),
(24, 'TM471A 4 CS, Graduation Project-A', '4', 4, 1, 1, 1),
(25, 'TM366 8 Artificial Intelligence', '8', 4, 1, 2, 1),
(26, 'TM471B 4 CS, Graduation Project-B', '4', 4, 1, 2, 1),
(27, 'GR101 3 Self-Learning Skills \r\n', '3', 1, 1, 1, 2),
(28, 'AR111 3 Arabic Communication Skills \r\n', '3', 1, 1, 1, 2),
(29, 'EL111 3 English Communication Skills \r\n', '3', 1, 1, 1, 2),
(30, 'TU170 3 Computing Essentials \r\n', '3', 1, 1, 1, 2),
(31, 'MT131 4 Discrete Mathematics', '4', 1, 1, 1, 2),
(32, 'AR112 3 Arabic Communication Skills \r\n', '3', 1, 1, 2, 2),
(33, 'EL112 3 English Communication Skills ', '3', 1, 1, 2, 2),
(34, 'TM103 4 Computer Organization and\r\nArchitecture', '4', 1, 1, 2, 2),
(35, 'MT129 4 Calculus and Probability \r\n', '4', 1, 1, 2, 2),
(36, 'GR111  3 Arabic Islamic Civilization \r\n', '3', 1, 1, 2, 2),
(37, 'TM105 4 Introduction to Programming \r\n', '4', 2, 1, 1, 2),
(38, 'MT132 4 Linear Algebra \r\n', '4', 2, 1, 1, 2),
(39, 'TM111 8 Introduction to Computing and Information Technology I', '8', 2, 1, 1, 2),
(40, 'TM112 8 Introduction to Computing and Information Technology II', '8', 2, 1, 2, 2),
(41, 'M251 8 Object-Oriented Programming using Java', '8', 2, 1, 2, 2),
(42, 'MS102 3 Physics', '3', 2, 1, 2, 2),
(43, 'TM260 4 Security, Ethics and Privacy in IT and Computing', '4', 3, 1, 1, 2),
(44, 'T215A 8 Communication and Information Technologies-A', '8', 3, 1, 1, 2),
(45, 'T215B 8 Communication and Information Technologies-B', '8', 3, 1, 2, 2),
(46, 'M269 8 Algorithms, Data Structures and Computability\r\n', '8', 3, 1, 2, 2),
(47, 'M109 3  .NET Programming', '3', 3, 1, 2, 2),
(48, 'TM351 8 Data Management and\r\nAnalysis', '8', 4, 1, 1, 2),
(49, 'TM355 8 Communications Technology', '8', 4, 1, 1, 2),
(50, 'TM471A 4 ITC, Graduation Project-A\r\n', '4', 4, 1, 1, 2),
(51, 'TM354 8 Software Engineering \r\n', '8', 4, 1, 2, 2),
(52, 'TM471B 4 ITC, Graduation Project-B \r\n', '4', 4, 1, 2, 2),
(53, 'GR101 3 Self-Learning Skills \r\n', '3', 1, 1, 1, 3),
(54, 'AR111 3 Arabic Communication Skills ', '3', 1, 1, 1, 3),
(55, 'EL111 3 English Communication Skills \r\n', '3', 1, 1, 1, 3),
(56, 'TU170 3 Computing Essentials \r\n', '3', 1, 1, 1, 3),
(57, 'MT131 4 Discrete Mathematics ', '4', 1, 1, 1, 3),
(58, 'AR112 3 Arabic Communication Skills ', '3', 1, 1, 2, 3),
(59, 'EL112 3 English Communication Skills ', '3', 1, 1, 2, 3),
(60, 'TM103 4 Computer Organization and\r\nArchitecture', '4', 1, 1, 2, 3),
(61, 'MT129 4 Calculus and Probability', '4', 1, 1, 2, 3),
(62, 'M109 3 .NET Programming', '3', 1, 1, 2, 3),
(63, 'TM105 4 Introduction to Programming', '4', 2, 1, 1, 3),
(64, 'MT132 4 Linear Algebra', '4', 2, 1, 1, 3),
(65, 'TM111 8 Introduction to Computing and Information Technology I', '8', 2, 1, 1, 3),
(66, 'BUS110 8 Introduction to Business', '8', 2, 1, 2, 3),
(67, 'TM260 4 Security, Ethics and Privacy in IT and Computing', '4', 2, 1, 2, 3),
(68, 'MS102 3 Physics', '3', 2, 1, 2, 3),
(69, 'M251 8 Object-Oriented Programming using Java', '8', 3, 1, 1, 3),
(70, 'B207A 8 Shaping Business Opportunities-A', '8', 3, 1, 1, 3),
(71, 'M269 8 Algorithms, Data Structures and Computability', '8', 3, 1, 2, 3),
(72, 'B207B 8 Shaping Business Opportunities B', '8', 3, 1, 2, 3),
(73, 'GR131 3 General Branch Requirement', '3', 3, 1, 2, 3),
(74, 'TM351 8 Data Management and\r\nAnalysis', '8', 4, 1, 1, 3),
(75, 'BUS310 8 Strategic Management', '8', 4, 1, 1, 3),
(76, 'TM471A 4 CwB, Project-A\r\n', '4', 4, 1, 1, 3),
(77, 'T352 8 Web, Mobile and Cloud\r\nTechnologies', '8', 4, 1, 2, 3),
(78, 'TM471B 4 CwB, Project-B \r\n', '4', 4, 1, 2, 3),
(79, 'GR101 3 Self-Learning Skills', '3', 1, 1, 1, 4),
(80, 'AR111 3 Arabic Communication Skills', '3', 1, 1, 1, 4),
(81, 'EL111 3 English Communication Skills', '3', 1, 1, 1, 4),
(82, 'TU170 3 Computer essentials ', '3', 1, 1, 1, 4),
(83, 'MT131 4 Discrete Mathematics', '4', 1, 1, 1, 4),
(84, 'AR112 3 Arabic Communication Skills', '3', 1, 1, 2, 4),
(85, 'EL112 3 English Communication Skills', '3', 1, 1, 2, 4),
(86, 'TM103 4 Computer Organization and\r\nArchitecture', '4', 1, 1, 2, 4),
(87, 'MT129 4 Calculus and Probability \r\n', '4', 1, 1, 2, 4),
(88, 'M109  3 .NET Programming', '3', 1, 1, 2, 4),
(89, 'TM105 4 Introduction to Programming ', '4', 2, 1, 1, 4),
(90, 'MT132 4 Linear Algebra ', '4', 2, 1, 1, 4),
(91, 'TM111 8 Introduction to Computing and Information Technology ', '8', 2, 1, 1, 4),
(92, 'TM112 8 Introduction to Computing and Information Technology II', '8', 2, 1, 2, 4),
(93, 'M251 8 Object-Oriented Programming\r\nusing Java', '8', 2, 1, 2, 4),
(94, 'MS102 3 Physics', '3', 2, 1, 2, 4),
(95, 'TM260 4 Security, Ethics and Privacy in IT and Computing', '4', 3, 1, 1, 4),
(96, 'T216A 8 Cisco Networking (CCNA)-A', '8', 3, 1, 1, 4),
(97, 'T216B 8 Cisco Networking (CCNA)-B', '8', 3, 1, 2, 4),
(98, 'T227 8 Change, Strategy and Project at Work', '8', 3, 1, 2, 4),
(99, 'GR112 3  Issues and Problems of Development in the Arab World ', '3', 3, 1, 2, 4),
(100, 'T316 8 Advanced Networking ', '8', 4, 1, 1, 4),
(101, 'TM352 8 Web, Mobile and Cloud\r\nTechnologies', '8', 4, 1, 1, 4),
(102, 'TM471A 4 N&S, Project-A\r\n', '4', 4, 1, 1, 4),
(103, 'T318 8 Applied Network Security \r\n', '8', 4, 1, 2, 4),
(104, 'TM471B 4 N&S, Project-B', '4', 4, 1, 2, 4),
(105, 'GR101 3 Self-Learning Skills', '3', 1, 1, 1, 5),
(106, 'AR111 3 Arabic Communication Skills', '3', 1, 1, 1, 5),
(107, 'EL111 3 English Communication Skills', '3', 1, 1, 1, 5),
(108, 'TU170 3 Computer essentials ', '3', 1, 1, 1, 5),
(109, 'MT131 4 Discrete Mathematics', '4', 1, 1, 1, 5),
(110, 'AR112 3 Arabic Communication Skills', '3', 1, 1, 2, 5),
(111, 'EL112 3 English Communication Skills', '3', 1, 1, 2, 5),
(112, 'TM103 4 Computer Organization and\r\nArchitecture', '4', 1, 1, 2, 5),
(113, 'MT129 4 Calculus and Probability', '4', 1, 1, 2, 5),
(114, 'GR111 3 Arabic Islamic Civilization', '3', 1, 1, 2, 5),
(115, 'TM105 4 Introduction to Programming \r\n \r\n', '4', 2, 1, 1, 5),
(116, 'MT132 4 Linear Algebra', '4', 2, 1, 1, 5),
(117, 'TM111 8 Introduction to Computing and Information Technology I', '8', 2, 1, 1, 5),
(118, 'TM112 8 Introduction to Computing and Information Technology \r\n\r\n\r\n', '8', 2, 1, 2, 5),
(119, 'M269 8 Algorithms, Data Structures and Computability', '8', 2, 1, 2, 5),
(120, 'MS102 3 Physics ', '3', 2, 1, 2, 5),
(121, 'TM260 4 Security, Ethics and Privacy in IT and Computing TM111\r\n', '4', 3, 1, 1, 5),
(122, 'T227 8 Change, Strategy and Project\r\nat Work', '8', 3, 1, 1, 5),
(123, 'M251 8 Object-Oriented Programming\r\nusing Java \r\n', '8', 3, 1, 2, 5),
(124, 'TT284 8 Web Technologies', '8', 3, 1, 2, 5),
(125, 'M109 3 .NET Programming ', '3', 3, 1, 2, 5),
(126, 'TM352 8 Web, Mobile and Cloud\r\nTechnologies \r\n\r\n', '8', 4, 1, 1, 5),
(127, 'TM354 8 Software Engineering ', '8', 4, 1, 1, 5),
(128, 'TM471A 4 WD, Project-A', '4', 4, 1, 1, 5),
(129, 'TM356 8 Interaction Design and the User Experience \r\n', '8', 4, 1, 2, 5),
(130, 'TM471B 4 WD, Project-B', '4', 4, 1, 2, 5),
(131, 'GR101 3 Self-Learning Skills \r\n\r\n', '3', 1, 2, 1, 6),
(132, 'AR111 3 Arabic Communication Skills ', '3', 1, 2, 1, 6),
(133, 'EL111 3 English Communication Skills \r\n', '3', 1, 2, 1, 6),
(134, 'TU170 3 Computing Essentials', '3', 1, 2, 1, 6),
(135, 'BUS101 4 Introduction to Mathematics for Business', '4', 1, 2, 1, 6),
(136, 'AR112 3 Arabic Communication Skills \r\n \r\n', '3', 1, 2, 2, 6),
(137, 'EL112 3 English Communication Skills', '3', 1, 2, 2, 6),
(138, 'BUS102 4 Introduction to Statistics', '4', 1, 2, 2, 6),
(139, 'ECO101 4 Principles of Microeconomics', '4', 1, 2, 2, 6),
(140, 'GR111 3 Arabic Islamic Civilization', '3', 1, 2, 2, 6),
(141, 'ECO102 4 Principles of Macroeconomics', '4', 2, 2, 1, 6),
(142, 'BUS110 8 Introduction to business studies', '8 ', 2, 2, 1, 6),
(143, 'GR131 3 General Branch Requirement', '3', 2, 2, 1, 6),
(144, 'LB170 8 Business communication skills', '8', 2, 2, 2, 6),
(145, 'B2O7A 8 Building Business Opportunities (1)', '8', 2, 2, 2, 6),
(146, 'B2O7B 8 Building Business Opportunities (2)', '8', 3, 2, 1, 6),
(147, 'BUS109 4 Commercial law', '4', 3, 2, 1, 6),
(148, 'BUS310 8 Strategic management', '8', 3, 2, 1, 6),
(149, 'B122 8 Introduction to Retail Management and Marketing', '8', 3, 2, 2, 6),
(150, 'BUS115 4 Small project management', '4', 3, 2, 2, 6),
(151, 'B123 8 management practices', '8', 4, 2, 1, 6),
(152, 'BUS202 4 data analysis', '4', 4, 2, 1, 6),
(153, 'B124 8 Principles of financial and management accounting', '8', 4, 2, 2, 6),
(154, 'B292 8 accounting administration', '8', 4, 2, 2, 6),
(155, 'ACC300 8 accounting information system', '8', 4, 2, 2, 6),
(156, 'B291 8 Financial Accounting', '8', 4, 2, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(15) NOT NULL,
  `uniid` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `uniid`, `password`) VALUES
(1, '1851710014', '1234'),
(2, '1851711056', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `years`
--

CREATE TABLE `years` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `years`
--

INSERT INTO `years` (`id`, `name`) VALUES
(1, 'first 1 one'),
(2, 'second 2 two'),
(3, 'third 3 three'),
(4, 'fourth 4 four');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `majors`
--
ALTER TABLE `majors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `facmaj` (`faculty_id`);

--
-- Indexes for table `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `facsub` (`faculty_id`),
  ADD KEY `semsub` (`semester_id`),
  ADD KEY `majsub` (`major_id`),
  ADD KEY `yeasub` (`year_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `years`
--
ALTER TABLE `years`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faculties`
--
ALTER TABLE `faculties`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `majors`
--
ALTER TABLE `majors`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `semesters`
--
ALTER TABLE `semesters`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `years`
--
ALTER TABLE `years`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `majors`
--
ALTER TABLE `majors`
  ADD CONSTRAINT `facmaj` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `facsub` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`),
  ADD CONSTRAINT `majsub` FOREIGN KEY (`major_id`) REFERENCES `majors` (`id`),
  ADD CONSTRAINT `semsub` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`),
  ADD CONSTRAINT `yeasub` FOREIGN KEY (`year_id`) REFERENCES `years` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
